export const education = [
    {
        school: "College of Applied Science",
        degree: "Bachelor's Degree in Computer Science",
        start: "2019",
        end: "2022",
    },
];