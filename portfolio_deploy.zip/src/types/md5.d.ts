declare module "md5" {
  const md5: (input: string) => string;
  export default md5;
}
